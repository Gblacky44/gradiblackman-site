// Afficher la section publication quand on clique sur son bouton
document.querySelectorAll("nav button").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll("main section").forEach((sec) => {
      sec.style.display = "none";
      sec.classList.remove("active");
    });
    const id = button.getAttribute("data-section");
    const section = document.getElementById(id);
    if (section) {
      section.style.display = "block";
      section.classList.add("active");
    }
  });
});

// Gérer le formulaire de publication
const form = document.getElementById("form-post");
const postList = document.getElementById("postList");

form.addEventListener("submit", (e) => {
  e.preventDefault(); // empêcher le rechargement de la page
  const titre = document.getElementById("postTitle").value.trim();
  const contenu = document.getElementById("postContent").value.trim();

  if (titre && contenu) {
    const li = document.createElement("li");
    li.innerHTML = `<strong>${titre}</strong><br>${contenu}`;
    // Ajouter le nouveau post en haut de la liste
    postList.prepend(li);

    // Reset du formulaire
    form.reset();
  } else {
    alert("Merci de remplir le titre et le contenu.");
  }
});
// Charger les posts au démarrage
function chargerPosts() {
  const postsJSON = localStorage.getItem("posts");
  if (postsJSON) {
    const posts = JSON.parse(postsJSON);
    posts.forEach((post) => ajouterPostDansDOM(post.titre, post.contenu));
  }
}

// Ajouter un post dans le DOM
function ajouterPostDansDOM(titre, contenu) {
  const li = document.createElement("li");
  li.innerHTML = `<strong>${titre}</strong><br>${contenu}`;
  postList.prepend(li);
}

// Gérer le formulaire avec stockage
form.addEventListener("submit", (e) => {
  e.preventDefault();
  const titre = document.getElementById("postTitle").value.trim();
  const contenu = document.getElementById("postContent").value.trim();
  if (titre && contenu) {
    ajouterPostDansDOM(titre, contenu);

    // Sauvegarder dans localStorage
    const postsJSON = localStorage.getItem("posts");
    let posts = postsJSON ? JSON.parse(postsJSON) : [];
    posts.unshift({ titre, contenu });
    localStorage.setItem("posts", JSON.stringify(posts));

    form.reset();
  } else {
    alert("Merci de remplir le titre et le contenu.");
  }
});

// Au chargement de la page, afficher les posts sauvegardés
window.addEventListener("DOMContentLoaded", chargerPosts);
